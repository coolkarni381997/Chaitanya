length = int(input("Enter the size of array: "))
arr = []
sum = avg = 0
for i in range(length):
    arr.append(int(input("Enter element: ")))
    sum += arr[i]
avg = sum/length
print("Average of N numbers: ",avg)