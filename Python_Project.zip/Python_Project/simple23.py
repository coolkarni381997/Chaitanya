import pymysql
# pymysql by default uses MySQL database

db = pymysql.connect("localhost","root","root","pydb")
if(db):
    # connect() method connects to the MySQL database using location, credentials and database_name
    print("Connected")
    cursor = db.cursor()

    sql_query = "show tables"
    if(cursor.execute(sql_query)):
        tables = cursor.fetchone()
        print(tables)

    sql_query7 = "alter table user drop age"
    if (cursor.execute(sql_query7)):
        db.commit()
        print("Table altered!")

    sql_query1 = "insert into user values(1234, 'Tejas Kawthalkar', 'Intern', 'Pune')"
    if(cursor.execute(sql_query1)):
        db.commit()
        print("Inserted!")

    sql_query2 = "select * from user"
    if (cursor.execute(sql_query2)):
        results = cursor.fetchall()
        for row in results:
            emp_id = row[0]
            emp_name = row[1]
            emp_desg = row[2]
            location = row[3]
            print("Emp Id:", emp_id," Emp Name:", emp_name," Emp Designation:", emp_desg, " Location:", location)

    sql_query3 = "delete from user where emp_id=55477"
    if (cursor.execute(sql_query3)):
        db.commit()
        print("Deleted!")

    sql_query4 = "select * from user"
    if (cursor.execute(sql_query4)):
        results = cursor.fetchall()
        for row in results:
            emp_id = row[0]
            emp_name = row[1]
            emp_desg = row[2]
            location = row[3]
            print("Emp Id:", emp_id, " Emp Name:", emp_name, " Emp Designation:", emp_desg, " Location:", location)

    sql_query5 = "alter table user add column age int"
    if (cursor.execute(sql_query5)):
        db.commit()
        print("Table altered!")

    sql_query6 = "insert into user values(55477, 'Nikhil Singh', 'Asso. Soft. Er.', 'Pune', 22)"
    if (cursor.execute(sql_query6)):
        db.commit()
        print("Inserted!")

    sql_query8 = "update user set age=21 where emp_id=55476"
    if (cursor.execute(sql_query8)):
        db.commit()
        print("Record Updated!")

    sql_query9 = "select * from user"
    if (cursor.execute(sql_query9)):
        results1 = cursor.fetchall()
        for row in results1:
            emp_id = row[0]
            emp_name = row[1]
            emp_desg = row[2]
            location = row[3]
            print("Type of fetched result:", type(row))
            print("Emp Id:", emp_id, " Emp Name:", emp_name, " Emp Designation:", emp_desg, " Location:", location)

    db.close()