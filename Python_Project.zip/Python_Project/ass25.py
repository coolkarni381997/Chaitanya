class Rectangle:
    def __init__(self, length, breadth):
        self.length = length
        self.breadth = breadth

    def area(self):
        area = self.length * self.breadth
        return area

rect = Rectangle(2,5)
print("Area of rectangle: ", rect.area())