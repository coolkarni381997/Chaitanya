string = str(input("Enter a string: "))

str1 = string[0] + string[1:len(string)].replace(string[0], '$')

print(str1)