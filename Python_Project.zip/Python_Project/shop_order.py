class Customer:
    def __init__(self, cust_id, cust_name, cust_order):
        self.cust_id = cust_id
        self.cust_name = cust_name
        self.cust_order = cust_order
        self.prod_cost = {'Dosa': {'cost':40,'qty':2}, 'Idli': {'cost':30,'qty':10}, 'Medu_Vada': {'cost':45,'qty':8}}
        self.total_cost = 0
    def calc_cost(self):
        for key, value in self.cust_order.items():
            if(not self.prod_cost.get(key)):
                print(key, " product not available!")
                continue
            else:
                if(self.prod_cost[key]['qty'] == 0):
                    print(key, " out of stock!")
                    continue
                elif(self.prod_cost[key]['qty'] <= value):
                    print(key, " quantity available is ", self.prod_cost[key]['qty'], " less than ", value, " what you ordered!")
                    continue
                else:
                    self.total_cost += self.prod_cost[key]['cost'] * value
                    self.prod_cost[key]['qty'] -= value

        return self.total_cost
    def available_qty(self):
        print("Updated Availability of products: ", self.prod_cost)

cust = Customer(111,'Chaitanya',{'Dosa':3, 'Idli':2, 'Medu_Vada':4, 'Shira':2})
print("Total cost: ", cust.calc_cost())
cust.available_qty()
