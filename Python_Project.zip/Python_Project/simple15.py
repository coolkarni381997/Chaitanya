class TemperatureConverter:
    def __init__(self, temperature = 0):
        self._temperature = temperature
        # Here 'temperature' is made 'private' member of class using '_' before variable name
        # '__' is used to have strict private modifier which would not be accessed in another module of python

    def get_temperature(self):
        print("Getting Value of _temperature which is private!")
        return self._temperature # This is how we access private member of a class using a method which returns it

    def set_temperature(self, value):
        if (value < -273):
            print("Temperature is below -273 is not acceptable!")
        else:
            print("Setting value of _temperature which is private!")
            self._temperature = value
            # This is how value of a private member of a class is set using a method
            # which is passed with a value to be assigned to a private member of the class

    temperature = property(get_temperature, set_temperature)
    # Using property() inside class where getter and setter methods are passed,
    # to set value of non-private member to a private member inside class

    def to_fahrenheit(self):
        return (self._temperature * 1.8)+32

# Still if any variable is private(_abc) in a class in a script it is accessible in that particular script out of class,
# as python doesn't support access modifiers properly,
# but when we embed it with some other application it will give an error

obj = TemperatureConverter()
obj.temperature = 38
print(obj.temperature)
# Here user gets to set value to a private member of a class from a non private member which user gets to use
# Here user doesn't get to see the private member
# So the private member's value is not always set in class and we can have dynamic values for a member in class

print(obj.to_fahrenheit())