string = str(input("Enter a string: "))
print("Character count of entered string/word is: ",len(string))