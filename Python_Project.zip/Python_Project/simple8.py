# List Comprehension

h_letters = []

for letter in 'human':
    h_letters.append(letter)

# h_letters = 'human'.toCharArray()
print(h_letters)

letters = ['' for letter in range(len('human'))]
print("Creation of empty list using list comprehension: ",letters)
letters = [letter for letter in 'human']
# List comprehension
print("Creation of list using list comprehension from 'human' string: ",letters)

# Using normal iteration and append() method for creating a numeric list
num_list1 = []
for num1 in range(1,21):
    num_list1.append(num1)
print(num_list1)

# Using list comprehension for creating a numeric list
num_list2 = [ num for num in range(1,21)]
print(num_list2)

# Using normal iteration and append() method for putting only even numbers from a list to a new empty list
num_list = []
for num3 in num_list1:
    if(num3%2==0):
        num_list.append(num3)

# Using List comprehension for putting only even numbers from a list to a new empty list
num_list4 = [num4 for num4 in num_list1 if num4 % 2 == 0]
print(num_list4)

num_list5 = [num5 for num5 in num_list1 if(num5 % 2 == 0 and num5 % 5 == 0)]
print(num_list5)

# Checking if a number is Even or Odd within a range using List Comprehension
obj = ['Even' if i % 2 == 0 else 'Odd' for i in range(10)]
print(obj)

obj1 = [str(i)+" is Even!" if i % 2 == 0 else str(i)+" is Odd!" for i in range(10)]
print(obj1)

num_list5 = [ num * num for num in range(1,21) if num % 2 != 0 ]
print(num_list5)