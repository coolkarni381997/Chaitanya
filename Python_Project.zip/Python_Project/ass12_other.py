string = str(input("Enter a string: "))
list1 = string.split(" ")
list2 = []
flag = 0
for item in list1:
    if(flag == 1):
        replaced_character = item.replace(item[0], "$")
        list2.append(replaced_character)
    else:
        flag = 1
        list2.append(item)
        continue

str1 = str(" ".join(list2))
print("New string after replacing every word's first character with '$': ", str1, " ", type(str1))