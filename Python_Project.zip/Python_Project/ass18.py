a_list = [10,2,3,7,4,8,1,22,5]
b_list = list(set(a_list))
print("Sorted list after removing duplicates: ", b_list)
print("Second smallest element is '{}' in given list: {}".format(b_list[1],a_list))
