#Modules and Packages in Python

a = 10

def sya_hi():
    print("Hello World!")

def print_msg(msg):
    print("\nMessage from Module1: ", msg)
    return "Reply from Module2: Fine, Thank You! How do you do?"

class Test:
    def class_addition(self, num1, num2):
        return num1 + num2