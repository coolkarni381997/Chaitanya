# Inheritance  in python
# Python supports method overriding but not overloading

class Person: #Super Class / Parent Class
    def __init__(self, name, address):
        print("Initializing data members of Super Class")
        self.name = name
        self.address = address
    def display_info(self):
        print("Super/Parent Class' display_info() method!")
        print("Name is: ", self.name)
        print("Address is: ", self.address)

class Employee(Person): # Derived Class / Child Class
    # Here Employee class is inheriting the properties of Person Class
    def __init__(self, name, address, emp_id, designation):
        Person.__init__(self, name, address) # This is similar to 'super()' in TypeScript
        # Here we are calling the constructor of Super Class to initialize its data members
        # OR
        #super().__init__(name, address)
        print("Initializing data members of Derived Class")
        self.emp_id = emp_id
        self.designation = designation
    def print_info(self):
        # self.display_info() # Calling the method of super class
        # OR
        Person.display_info(self) # Calling the method of super class
        print("Derived/Child Class' print_info() method!")
        print("Employee ID: ", self.emp_id)
        print("Designation is: ", self.designation)

emp = Employee('Chaitanya', 'Pune', 55476, 'Associate Software Engineer (G1) Development')
emp.display_info() # Calling the method of Super Class using Object of Derived Class
emp.print_info() # Calling the method of Derived Class using its own Object