# File Handling in Python

fileRead = open("file.txt", "r") # Used to open a file in read mode
# Instead of just filename we can also provide file-path
data = fileRead.read() # Used to read the opened file
print(data)
fileRead.close() # Used to close the opened file

fileWrite = open("myfile.txt", "w")
# This will open the file in write mode and if the file doesn't exist, then it will create new one
fileWrite.write("This is text to write again\n")
fileWrite.close()

fileAppend = open("myfile.txt", "a")
# This will open the file in append mode and if the file doesn't exist, then it will create new one
fileAppend.write("This is text to write again\n")
fileAppend.close()

print("\nReading line by line: \n")
fileRead = open("file.txt", "r") # Used to open a file in read mode
while True:
    line = fileRead.readline() # Used to read one line from the opened file
    print(line)
    # Check if line is not empty
    if not line:
        break

print("File is closed? ", fileRead.closed)
print("Mode in which file is opened: ", fileRead.mode)
print("Name of file: ", fileRead.name)

fileRead.close() # Used to close the opened file