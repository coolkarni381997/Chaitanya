num1 = int(input("Enter a number: "))
num2 = int(input("Enter another number: "))
flag = False
if(num1==num2 or abs(num1-num2)==5 or num1+num2==5):
    flag = True
else:
    flag = False

print(flag)