def is_prime(num):
    count = 0
    for i in range(1,num+1):
        if(num%i==0):
            count += 1
    if(count>2):
        print(num, " is not a prime number!")
    elif(num == 1):
        print(num," is neither prime nor composite!")
    elif (num <= 1):
        print("Number should be a natural number!")
    else:
        print(num, " is a prime number!")

num = int(input("Enter a natural number to check if prime or not: "))
is_prime(num)