dict1 = {'key1':21,'key2':44,'key3':14,'key4':55,'key5':31}
max_dict1_value = max(dict1.values())
min_dict1_value = min(dict1.values())
print("Max value in dictionary: ",max_dict1_value)
print("Min value in dictionary: ",min_dict1_value)