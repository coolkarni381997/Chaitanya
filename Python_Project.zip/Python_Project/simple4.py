# 'Set' is just like 'list' but it is 'unindexed' and it is also mutable or can be modified
# Set doesn't not allow duplicate values / objects
# Set is unordered

colors = {'red','orange','yellow','green','blue','indigo','violet'}

print(colors)
print(type(colors))

# Add allows to add only single object to a set
colors.add('brown')
print(colors)

# Update allows to add multiple objects or a set to one set
colors.update(['purple','pink'])
print(colors)

colors.remove('indigo')
print(colors)

colors.discard('purple')
print(colors.discard('purple'))
# Above statement will print 'None' as 'discard()' method on a set 'won't return anything' it will just 'discard an element'
print(colors)

# If any element is not present in a set and we use 'remove()' then it will throw an error,
# whereas if we use 'discard()' it won't throw an error

colors.pop()
print(colors)
print(colors.pop())
# Pop will 'pop first element' from the set but as 'set is unordered' we 'don't know which one is first'

set1 = {1,2,3,4,5}
set2 = {1,4,6,8,9}
# Union operation
set3 = set1.union(set2)
print(set3)
# Intersection operation
set4 = set1.intersection(set2)
print(set4)
# Subtraction operation
set5 = set1 - set2

print(set5)
# Subtraction operation
set6 = set2 - set1

print(set6)
# Intersection Update operation
# It updates the set1 on which intersection_update() method is called,
# with the intersection of itself & the rest of the sets
set7 = set1
set8 = set2
print(set7)
print(set8)
set7.intersection_update(set2)
print(set7)
set8.intersection_update(set1)
print(set8)
set9 = set1
set10 = set2
print(set9)
print(set10)
set9.difference_update(set2)
print(set9)
set10.difference_update(set1)
print(set10)

set1.difference(set2)
print(set1)
set2.difference(set1)
print(set2)

set11 = {3,6,1,7,9,2,5,4,8,10}
set12 = sorted(set11)
# Sorted converts the set into a list and then sorts it
print("Sorted set12: ",set12)
print("Sorted set11 type: ",type(set11))
print("Sorted set12 type: ",type(set12))

set13 = set(set12)
print("",type(set13))
set12.reverse()
# Reverese 'reverses a set' only if it has been 'converted into a list' using 'list() or sorted()'
print(set12)