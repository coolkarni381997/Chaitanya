temp_f = float(input("Enter temperature in degree Fahrenheit: "))
temp_c = float((temp_f-32)/1.8)
print("Temperature in degree Celsius: ",temp_c)