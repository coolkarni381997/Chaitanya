num = int(input("Enter a number till which sum of numbers is to be found: "))
sum = 0
for i in range(num+1):
    sum += i

print("Sum is: ", sum)