# Tuple isn't mutable or can't be modified

a_tuple = (1,2,3)
print(a_tuple)
print(type(a_tuple))
print(a_tuple[0])
# a[1] = 4 will give an error cause tupples are immutable
# del a_tuple[0] will give an error cause tupples are immutable, so we can't delete an element
del a_tuple
# We can delete the whole tuple but not any element of it

b_tuple = (1,2,3,4)
c_tuple = (5,6)
add = b_tuple + c_tuple
print(add)
print(type(add))

d_tuple = ("Hi")
print(d_tuple * 4)

print(len(b_tuple))
print(min(b_tuple))
print(max(b_tuple))
e_tuple = tuple([1,2,3,4])
print(e_tuple)