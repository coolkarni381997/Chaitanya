# Accepting input in python3

num1 = int(input("Enter a number: "))
print(num1," ",type(num1))
num2 = float(input("Enter a number: "))
print(num2," ",type(num2))
str1 = str(input("Enter a string: "))
print(str1," ",type(str1))

if(num1<100):
    print(num1," is smaller than 100!")
else:
    print(num1, " is greater than 100!")