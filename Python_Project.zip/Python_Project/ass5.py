height = float(input("Enter height of triangle: "))
base = float(input("Enter base of triangle: "))
area = base * height / 2
print("Area of triangle: ",area)