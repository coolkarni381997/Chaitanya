# Multiple Inheritance in Python

class ParentClass1:
    def __init__(self, name):
        self.name = name
        print("***ParentClass1***")

    def display_info(self):
        print("ParentClass1 name: ", self.name)

class ParentClass2:
    def __init__(self, address):
        self.address = address
        print("***ParentClass2***")

    def display_info(self):
        print("ParentClass2 name: ", self.address)

class ChildClass(ParentClass1, ParentClass2):
    def __init__(self, name, address, age):
        ParentClass1.__init__(self,name)
        ParentClass2.__init__(self,address)
        print("***ChildClass***")
        self.age = age
    def display_info(self):
        ParentClass1.display_info(self)
        ParentClass2.display_info(self)
        print("ChildClass age: ", self.age)

child_class = ChildClass('Chaitanya', 'Pune', 21)
child_class.display_info()
# Method overriding is also implemented in the above example,
# where all the method names are same and method of ChildClass' method is overriding other parent class' methods