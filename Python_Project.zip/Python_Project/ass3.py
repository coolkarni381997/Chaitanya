print("Enter 3 numbers: ")
arr1 = []
sum = 0
for i in range(3):
    arr1.append(int(input("Enter number: ")))
    sum += arr1[i]

if(arr1[0]==arr1[1] and arr1[1]==arr1[2]):
    print("Sum: ",sum * 3)
else:
    print("Sum: ",sum)