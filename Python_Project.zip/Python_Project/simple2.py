# List is mutable or can be modified

a_list = [1,2,"python",3,4,"Hello"]
print(type(a_list))

for abc in a_list:
    print(abc,end=", ")

print("\n")
for i in range(len((a_list))):
    if(i==2):
        print(a_list[i])
    elif (i == 4):
        del a_list[i]
        # Deleting a particular element in a list
    elif(i == 3):
        a_list[i] = "Hello World!"
        # Updating a particular element in a list
        print(a_list[i])

print(a_list)

b_list = [6,7,"Java"]
c_list = a_list + b_list
print(c_list)

num_list1 = list(range(10))
print(num_list1)

str_list = list("Apple")
print(str_list)

a = [1,2,3,4,5]
print("Maximum element in list: ",max(a))
print("Minimum element in list:",min(a))

b = ["Apple","Ball","Cat","Apple","Cat"]
print("Maximum element in list: ",max(b))
print("Minimum element in list:",min(b))

# Append appends an object from the last
b.append("Dog")
print(b)

# Extend extends a list from the list with another string
b.extend(["Dog","Horse","Elephant"])
print(b)

# Count counts the occurrences of an object in a list
count = b.count("Apple")
print("Number of occurrences of Apple in list: ",count)

# Pop pops an object from a list from the last
b.pop()
print(b)

# Insert inserts an object in a list at a specified index
b.insert(2,"Dog")
print(b)

# Remove removes an object from a list
b.remove("Apple")
print(b)

# Reverse reverses a list
b.reverse()
print(b)

# Sort sorts the list
b.sort()
print(b)