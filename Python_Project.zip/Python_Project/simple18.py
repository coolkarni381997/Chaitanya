# Customized exception

class ValueTooSmallError(ValueError):
    def __init__(self, msg):
        self.msg = msg

class ValueTooLargeError(ValueError):
    def __init__(self, msg):
        self.msg = msg

# ValueTooLargeError and ValueTooSmallError classes are defined to define exceptions by
#  extending 'ValueError' class in Exception

while True:
    try:
        num = int(input("Enter a number: "))
        if(num<20):
            raise ValueTooSmallError("This value is too small, try again!")
        # 'raise' is used to 'explicitly raise an exception' just like 'throw' in java
        elif(num>1000):
            raise ValueTooLargeError("This value is too large, try again!")
        else:
            print("You entered: ", num)
    except ValueTooSmallError as e:
        print(type(e)," ", e)
        #print(e.args)
    except ValueTooLargeError as e:
        print(type(e)," ", e)
        #print(e.args)
