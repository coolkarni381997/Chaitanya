string = str(input("Enter a string: "))
if(len(string)<2):
    print("String is Empty!")
else:
    print(string[:2]+string[len(string)-2:])