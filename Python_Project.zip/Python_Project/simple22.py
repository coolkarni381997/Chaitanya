# Importing Packages in Python

# All modules from the mentioned packages can be imported using 'from package_name import *'
# In '__init__.py' in package we need to use ' __all__ = ['list of package_names'] ' for using import *

from simple22_package import *
print(module_1.printMsg())
print(module_2.sayHi())

#OR
# If we mention all methods/elements of all modules in '__init__.py' in package,
#  in that case we can use directly package object to access all methods/elements of all modules
import simple22_package as p
print(p.displayMsg())
print(p.sayHello())

# OR
# Using package_name.module_name we can import package and its modules
import simple22_package.module_1 as module1
import simple22_package.module_2 as module2


print(module1.displayMsg())
print(module2.sayHi())