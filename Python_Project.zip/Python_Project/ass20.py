dict1 = {'key1':21,'key2':44,'key3':14,'key4':55,'key5':31,'key6':44,'key7':55}
unique = list(set(dict1.values()))
print("All unique values inside the dictionary {} are: {}".format(dict1, unique))