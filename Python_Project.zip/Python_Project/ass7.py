num1 = int(input("Enter a number: "))
num2 = int(input("Enter another number: "))
import math
ans = int(math.pow((num1 + num2),2))
print("Answer is: ",ans)