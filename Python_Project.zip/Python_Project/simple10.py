# Functions in python

def addition(num1, num2):
    return num1+num2

num3 = addition(111,666)
print(num3)

# Scope of variables in python

num1 = 10
num2 = 20

def modify1_num1():
    # Here num1 is a new variable with local scope is considered cause function can't modify the global variables
    num1 = 20
    print("Num1 is: ", num1)

def modify2_num1():
    # Here we are using global keyword so that global new1 & num2 variables will be considered
    global num1, num2
    num1 = 20
    num2 = 30
    print("Num1 is: ", num1)

print("Before modifying, Num1 is: ", num1)
modify1_num1()
print("After modifying num1 in local scope without global keyword, Num1 is: ", num1)
modify2_num1()
print("After modifying num1 in local scope with global keyword, Num1 is: ", num1)
print("Num2 after modifying its value using global keyword: ",num2)