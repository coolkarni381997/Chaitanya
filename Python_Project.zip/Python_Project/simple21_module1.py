# Modules in Python

# For importing whole module
import simple21_module2 as mod2

print("Value of variable 'a' coming from Module2: ", mod2.a)
msg1 = mod2.print_msg("How are you?")
print(msg1)
obj = mod2.Test()
addition = obj.class_addition(4, 5)
print("\nAddition is: ",  addition)

# For importing individual elements from a module
from simple21_module2 import a
from simple21_module2 import print_msg
from simple21_module2 import Test

print("\nValue of variable 'a' coming from Module2: ", a)
msg1 = print_msg("How are you?")
print(msg1)
obj = Test()
addition = obj.class_addition(4, 5)
print("\nAddition is: ",  addition)


