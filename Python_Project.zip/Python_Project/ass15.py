list1 = [1,2,3,4,5]
sum =0
for item in list1:
    sum += item
print("Sum of items in list: ",sum)