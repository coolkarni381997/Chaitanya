string = str(input("Enter a string: "))
if(len(string) >= 3):
    if(not string[len(string)-3:] == 'ing'):
        string += 'ing'
    else:
        string += 'ly'
else:
    string = string

print("String: ",string)
