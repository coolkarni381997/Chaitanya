# Python is an interpreted and Object Oriented language

print("Hello World!")
a = b = c = 1
print("a: ", a," b: ", b," c: ", c)
a, b, c, = 1, 2, "Hello"
print("a: ", a," b: ", b," c: ", c)
a = "hello" in "hello world"
print("Is hello available in given string? ",a)
a = 1 in [1,2,3]
print("Is 1 available in given array? ",a)

a = [1,2,3]
b = [1,2,3,4,5]

for i in b:
    print(i)

is_available = a in b
print(is_available)
is_available = a not in b
print(is_available)
# 'in' and 'not in' are 'containment operators'

num1 = 10
num2 = 10
print(id(num1))
print(id(num2))

isequal = num1 is num2
print("num1 is equal to num2? ", isequal)
isequal = num1 is not num2
print("num1 is equal to num2? ", isequal)
# 'is' and 'is not' are 'identity operators'
# 'id' is used to get the hashed location of a variable
# As num1 and num2 are same they share the same memory location, so memory is not wasted!

str1 = "Hello"
str2 = "Hello"
print(id(str1))
print(id(str2))

str3 = "Hello"
str4 = "Hello2"
print(id(str3))
print(id(str4))

isequal = str3 is str4
print("str3 is equal to str4? ", isequal)
isequal = str3 is not str4
print("str3 is equal to str4? ", isequal)

