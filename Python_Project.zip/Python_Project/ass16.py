a_list = [1,2,3,2,4,1,4]

a_list = list(set(a_list))

print(a_list)