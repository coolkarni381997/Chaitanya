a_tuple = (1,2,3,4,5)
a_list = list(a_tuple)
a_list = [ele for ele in reversed(a_list)]
print("Original tuple: ",a_tuple)
print("Reveresed tuple: ",tuple(a_list))