# Exception Handling in Python
num1 = int(input("Enter a number: "))
num2 = int(input("Enter another number: "))

try:
    num3 = int(num1 / num2)
    print("Division is: ",num3)
    a_list = [1, 2, 3, 4]
    print(a_list[4])

# For particular exception handling
# except (ZeroDivisionError):
#     print("Value of num2 can't be 0")
# For particular exception handling
# except (IndexError):
#     print("You are trying to access element which doesn't exist as index is out of bound ")

# For handling multiple exceptions in one except block using object of that exception,
# just like catch(Exception e) in java
except (ZeroDivisionError, IndexError) as e:
    print("Some exception occurred", type(e), e)
# Any one of them which will occur first will be handled first and program will terminate after handling the error

# For generic exception handling
# except (Exception):
#     print("Exception occurred")

# finally block executes even though an exception occurs
finally:
    print("It will still execute even if exception(i.e. error in python) occurs")