# Python Strings

a_string = 'Hello World!'
print(a_string)
print(a_string[2:7])
# ':' slice operator used to print a particular characters of a string
print(a_string[0])
print(a_string[1:])
# Printing string from 1st character till the end of string
print(a_string * 2)
# '*' repetition operator
print(a_string + " Bye!")
# '+' concatenation operator

b_string = a_string.split(' ')
# Split() uses a particular character to split a string into a list of elements ex., 'space' or 'comma'
print("String after splitting to form a list of elements: ",b_string)
print("Type of splitted string: ",type(b_string))
print("Original string: ",a_string)
print("Type of original string",type(a_string))