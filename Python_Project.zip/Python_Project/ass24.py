class ReverseString:
    def __init__(self, string):
        self.string = string
    def reverse_string(self):
        a = self.string.split(" ")
        print(a)
        b = []
        string1 = ""
        i = len(a) - 1
        while(i>=0):
            print(a[i])
            b.append(a[i])
            i -= 1
        string1 = " ".join(b)

        return string1

revstr = ReverseString('How are you?')
str1 = revstr.reverse_string()
print("Reversed string: ", str1)