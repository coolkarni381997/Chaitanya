# Classes in python

class MyClass:
    a = 10
    b = 20
    pers1 = 'Chaitanya'
    def __init__(self):
        print("Object Created!")
    def say_hello(self):
        print("Hello World!")

    def welcome_person(self):
        # 'self' is like 'this' in JavaScript to access data members of the current class
        print("Welcome ", self.pers1)

# Create an Object for the class MyClass
myClass = MyClass()
# Here constructor is called at the time of object creation and all the data members are initialized in it
print("A: ", myClass.a)
print("B:", myClass.b)
myClass.say_hello()
myClass.welcome_person()

# *** OR ***
#Another Class without constructor
class Person:
    def __init__(self,name,age): # This is a constructor in Python and
        # it is a parameterized constructor which enables dynamic essence
        # to have different values for every object while creating it
        # 'self' is like 'this' in JavaScript
        self.age = age
        self.name = name
    def display_members(self):
        print("Name: ", self.name, " Age: ", self.age)

p1 = Person('Chaitanya',21)
# 'Chaitanya' and 21 are the data members passed to the current object which would be initialized in the constructor
# Here constructor is called at the time of object creation and all the data members are initialized in it
p1.display_members()

p1 = Person('Nikhil',22)
p1.display_members()