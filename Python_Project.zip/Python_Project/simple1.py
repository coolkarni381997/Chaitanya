num1 = 20
# Conditional statements 'if', 'elif' and 'else'
if(num1 == 10):
    print("num1 is 10")
elif(num1 == 20):
    print("num1 is 20")
else:
    print("num1 is not 10")

# 'while' and 'for' loop

num2 = 1

while(num2<=10):
    print(num2,end=', ')
    num2 += 1

print("\n")
for i in range(10):
    print(i,end=', ')

print("\n")
for i in range(0,10):
    print(i,end=', ')

print("\n")
for i in range(5,10):
    print(i,end=', ')

print("\n")
for i in range(0,10,2):
    print(i,end=', ')

# In 'range()', 'upper bound' is *excluded* and 'lower bound' is by default *0* if not mentioned
# Third parameter in range() is considered to be the increment with which we want to increment

print("\n")
str1 = "Python"
for letter in str1:
    print(letter,end=', ')