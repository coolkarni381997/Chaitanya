# Use of assertion (assert) is for evaluating logical conditions or user defined conditions to be true or false and
# if false it returns an error/exception

def div(p , q):
    assert q != 0, "Divide by zero error!" # After comma there is msg to be printed as an error/exception
    return p / q

print(div(10, 5))
# print(div(10, 0))


# Handling assertion error/exception using try except block
try:
    def avg(marks):
        assert len(marks) != 0, "List is empty!"
        return sum(marks)/len(marks)

    marks1 = [55, 88, 78, 90, 79]
    print("Average of marks1: ",avg(marks1))

    marks2 = []
    print("Average of marks2: ",avg(marks2))

except AssertionError as e:
    print("Exceptionoccured: ", type(e), " ", e)