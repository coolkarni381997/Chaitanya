a_list = [1,2,3,4,5,6,7,8,9,10]
for item in a_list:
    if(item%2==0):
        print(item,end=", ")