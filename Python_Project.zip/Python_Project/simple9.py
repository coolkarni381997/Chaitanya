x=10
y=20
z=30
print("X is:",x,"Y is:",y,"Z is:",z)
print("X is: {} Y is: {} Z is: {}".format(x,y,z))

from string import Template
t = Template('X is $x')
print(t.substitute({'x':1}))

t = Template('$name is the $job of $company')
s = t.substitute(name='Tim Cook',job='CEO',company='Apple INC.')
print(s)

# Using dictionary approach to substitute in string template
dictionary = {'name':'Tim Cook','job':'CEO','company':'Apple INC.'}
s = t.substitute(dictionary)
print(s)

# ${} is used to concat or append something to an existing string variable
t = Template('$noun adjective is ${noun}ing')
s = t.substitute(noun='Test')
print(s)

# For multiple tuples to be printed which are part of a list we use following way
Student = [('Ram',90),('Ankit',78),('Bob',92)]
t = Template('Hi $name, you have got $marks marks.')

for item in Student:
    print(t.substitute(name=item[0], marks=item[1]))