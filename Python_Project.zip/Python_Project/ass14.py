string = str(input("Enter a string of multiple words: "))
list1 = string.split(" ")
for i in range(len(list1)):
    print("Occurrence of chracters in  word ",i+1," : ",len(list1[i]))