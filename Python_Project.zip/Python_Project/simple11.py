# Types of arguments in functions

# Required/Compulsory Arguments
def say_hello(user):
    print("Hello ",user)

say_hello('Chaitanya')

# Default/Optional Arguments can be used by having a default value for the argument,
# so it isn't necessary to pass those default valued arguments when we don't want to
def print_info1(fname, lname, age, address='Not Available'):
    print("First Name is ",fname)
    print("Last Name is ", lname)
    print("Age is ", age)
    print("Address is ", address)

print_info1('Nikhil', 'Singh', 21)

# Keyworded Arguments can be used for having arguments sequential arguments
def print_info2(fname, lname, age, location):
    print("First Name is ",fname)
    print("Last Name is ", lname)
    print("Age is ", age)
    print("Location is ", location)

print_info2(fname='Nikhil', lname='Singh', age=21, location='Pune')
print_info2('Nikhil', lname='Singh', age=21, location='Pune')

# Default/Optional Arguments can be used by having a default value for the argument,
# so it isn't necessary to pass those default valued arguments when we don't want to
def emp_info(emp_id, emp_name, emp_designation, company_name='Xoriant Solutions Pvt Ltd'):
    print("Employee Info: ", emp_id, ", ", emp_name, ", ", emp_designation, ", ", company_name)

emp_info(55476, 'Chaitanya Kulkarni', 'Associate Software Engineer (G1) Development')
emp_info(55477, 'Vaishnavi Darekar', 'Associate Software Engineer (G1) Testing')
emp_info(9768, 'Rupesh Dhake', 'Software Engineer (G2) Architect', 'Tieto')

# For passing varying number of arguments we can use * before name of argument ex., def display_data(*values):
def display_data(*values):
    print("Type of *values: ",type(values))
    for val in values:
        print(val, end=', ')

my_list = [1,2,3,4,5]
display_data(my_list)
my_list1 = [1,2,3,4,5,6,7]
display_data(my_list1)
display_data(1,'Hello',2,'Bye',3)

def display_data1(num1, *values):
    print("Type of *values: ",type(values))
    print(num1)
    for val in values:
        print(val, end=', ')

display_data1(1,'Hello',2,'Bye',3)
# Here num1 argument is the first parameter passed to the method call
# We can't have a single argument after a multi valued parameter like *values which is a tuple
# But if we use key-worded call then num1 can be passed at the last as well

def display_data2(*values, num1):
    print("Type of *values: ",type(values))
    print(num1)
    for val in values:
        print(val, end=', ')

display_data2(1,'Hello',2,'Bye',num1=3)
# We can't have an in between argument in the call to be key-worded it has to be the last or the first,
#  depending upon where the single argument is placed in the function call (first/last)

# For having key-worded argument of varying number we use ** before,
# the argument which is going to have varying key-worded arguments
def display_info(name, **info):
    print("\n",name)
    print(info)
    print("Type of varying number of key-worded argument: ",type(info))

display_info('Chaitanya', age=21, city='Pune', job='IT Professional')
# Here all the key-worded arguments will be stored in **info which is a dictionary