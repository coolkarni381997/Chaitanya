radius = float(input("Enter the radius of circle to calculate area: "))
area = radius*radius*3.14
print("Area of circle: ",area)