marks = {'maths':59,'science':59,'english':83}
cond1 = (marks['maths']>=60 and marks['science']>=60 and marks['english']>=60)
cond2 = ((marks['maths']>=60 and marks['science']>=60) or (marks['science']>=60 and marks['english']>=60) or (marks['maths']>=60 and marks['english']>=60))
cond3 = (marks['maths']<60 or marks['science']<60 or marks['english']<60)
if(cond1):
    print("Pass!")
elif(cond2 and not cond1):
    print("Promoted!")
elif(cond3 and not cond2):
    print("Fail!")