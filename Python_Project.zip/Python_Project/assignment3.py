import math
arm_num = 0
i = 100
for i in range(100,1000):
    arm_num = math.pow(int((i%10)),3) + math.pow(int((i%100)/10),3) + math.pow(int((i%1000)/100),3)
    if(arm_num == i):
        print(i," is an armstrong number!")
    else:
        print(i," is not an armstrong number!")