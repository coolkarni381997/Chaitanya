def printMsg():
    print("Good Morning from Module1")

def displayMsg():
    print("Welcome to Python from Module1")