# '__all__' is used to explicitly mention name of modules' to be' exported outside the package'
#__all__ = ['module_1']
# __all__ = ['module_2']

# By default '__all__' holds names of all modules inside that package
# __all__ = ['module_1','module_2']

# Whenever we are using __all__ explicitly we need to use from in __init__.py

# Used to import all methods/elements of all modules at package level,
# so that package object can be used in some other package to access all methods of all modules
from .module_1 import *
from .module_2 import *

# We can also import certain method from a module at package level
# from .module_1 import printMsg

# We can skip '__all__' and still can use 'from' to import specific or all methods of certain or all modules