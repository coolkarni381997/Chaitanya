def sayHi():
    print("Hi from Module2")

def sayHello():
    print("Hello from Module2")