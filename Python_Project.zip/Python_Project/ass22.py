div = []
for i in range(1500,2701):
    if(i%5==0 and i%7==0):
        div.append(i)

print("All numbers divisible by 7 and multiples of 5 between 1500 to 2700: \n",div)