# Dictionary is a comma separated {'key':value} paired data structure

employee = {'Name':'Chaitanya','Age':21,'Company':'Xoriant','Designation':'Associate Software Engineer (G1)','Experience':1}
print(employee)
print(type(employee))
print(employee['Name'])
print(employee['Age'])
print(employee['Company'])
print(employee['Designation'])
print(employee['Experience'])

# Modify dictionary element
employee['Age'] = 22
print(employee['Age'])
print(employee)

# Add dictionary element in {key:value} pair
employee['Location'] = 'Pune'
print(employee)

# Delete a {key:value} pair using del keyword
del employee['Experience']
print(employee)

# Pop and show a {key:value} pair using pop() method
print(employee.pop('Location'))
print(employee)

print("\n")
# Methods for iterating over dictionary
for key in employee.keys():
    print("Key: ",key)
    print("Values: ", employee[key])

print("\n")
for value in employee.values():
    print("Value: ",value)

print("\n")
for key, value in employee.items():
    print("Key: ",key)
    print("Value: ",value)

print("\n")
if 'Experience' in employee:
    print('Experience of employee: ',employee.get('Experience'))
else:
    print('Experience key is not available!')

print("\n")
employee['Experience'] = 2
print(employee)
if 'Experience' in employee:
    print('Experience of employee: ',employee.get('Experience'))
else:
    print('Experience key is not available!')

print("\n")

# If by default works on keys, so we have to use dict.values() to check the availability a value
if 'Chaitanya' in employee:
    print('Chaitanya is available!')
else:
    print('Chaitanya is not available!')

dictionary1 = {'name':'Ramesh','location':'Pune'}
dictionary2 = {'Technology_1':"Python","Technology_2":"Java"}
dictionary1.update(dictionary2)
# Update method will merge the 2 dictionaries and dictionary1 will have the pairs od dictionary2 added in it
print(dictionary1)
