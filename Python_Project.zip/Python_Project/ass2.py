num = int(input("Enter a number: "))
if(num>=901 and num<=1099):
    print("Within tolerence 100 of 1000")
elif(num>=1901 and num<=2099):
    print("Within tolerence 100 of 2000")
else:
    print("Enter a number within 901-1099 or 1901-2099")