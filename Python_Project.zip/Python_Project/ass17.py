a_list = [1,2,3,4]
b_list = [3,5,6]
#b_list = [5,6]

intsn = set(a_list).intersection(set(b_list))

if(len(intsn)>=1):
    print(True)
else:
    print(False)