# Exception handling in python
def get_number():
    number = float(input("Enter a float number: "))
    return number

while(True):
    try:
        print("Entered number: ", get_number())
    except(ValueError):
        print("You entered a wrong value!")
        break
    except:
        print("Unknown error")
        break
    # We can have else block along with try-except in python at the end of all except blocks
    else:
        print("Executing Fine")
        break
    # finally can be written after else if we have else in our code after except
    finally:
        print("Finally excutes anyways")